gdjs.evtsExt__HIV__runExposure = {};
gdjs.evtsExt__HIV__runExposure.repeatCount3 = 0;

gdjs.evtsExt__HIV__runExposure.repeatIndex3 = 0;

gdjs.evtsExt__HIV__runExposure.GDchipObjects1= [];
gdjs.evtsExt__HIV__runExposure.GDchipObjects2= [];
gdjs.evtsExt__HIV__runExposure.GDchipObjects3= [];
gdjs.evtsExt__HIV__runExposure.GDchipObjects4= [];
gdjs.evtsExt__HIV__runExposure.GDchipObjects5= [];
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects1= [];
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects2= [];
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3= [];
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects4= [];
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects5= [];
gdjs.evtsExt__HIV__runExposure.GDrunObjects1= [];
gdjs.evtsExt__HIV__runExposure.GDrunObjects2= [];
gdjs.evtsExt__HIV__runExposure.GDrunObjects3= [];
gdjs.evtsExt__HIV__runExposure.GDrunObjects4= [];
gdjs.evtsExt__HIV__runExposure.GDrunObjects5= [];

gdjs.evtsExt__HIV__runExposure.conditionTrue_0 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition3IsTrue_0 = {val:false};
gdjs.evtsExt__HIV__runExposure.conditionTrue_1 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition2IsTrue_1 = {val:false};
gdjs.evtsExt__HIV__runExposure.condition3IsTrue_1 = {val:false};


gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDrunObjects1Objects = Hashtable.newFrom({"run": gdjs.evtsExt__HIV__runExposure.GDrunObjects1});gdjs.evtsExt__HIV__runExposure.userFunc0x6d3670 = function(runtimeScene, objects, eventsFunctionContext) {
"use strict";
/**
Calcuate Risk

e.g.
The probability that a person has HIV infection is hiv_risk (.07) 
If one has sexual contact with 5 partners 
what is the probability that none has HIV infection?

Solution: To solve this problem, we compute 3 individual probabilities, using the binomial formula. The sum of all these probabilities is the answer we seek. Thus,
b(x = 0; 5, 0.3) = b(x = 0; 5, 0.07)  

x ( hits ) = 0
n ( times/picks ) = 5
P ( probablity/risk ) = .07


Given x, n, and P, we can compute the binomial probability based on the binomial formula:
Binomial Formula. 
Suppose a binomial experiment consists of n trials and results in x successes. If the probability of success on an individual trial is P, then the binomial probability is:
b(x; n, P) = nCx * Px * (1 - P)n - x
b(x; n, P) = { n! / [ x! (n - x)! ] } * Px * (1 - P)n - x
**/
function binomialProb( x, n, P ){

/**
use funcions from 
view-source:https://www.math.ucla.edu/~tom/distributions/binomial.html?
**/
	return computeBProb( x, n, P )
 

}



function LogGamma(Z) {
	 
		var S=1+76.18009173/Z-86.50532033/(Z+1)+24.01409822/(Z+2)-1.231739516/(Z+3)+.00120858003/(Z+4)-.00000536382/(Z+5);
		var LG= (Z-.5)*Math.log(Z+4.5)-(Z+4.5)+Math.log(S*2.50662827465);
	 
	return LG
}

function Betinc(X,A,B) {
	var A0=0;
	var B0=1;
	var A1=1;
	var B1=1;
	var M9=0;
	var A2=0;
	var C9;
	while (Math.abs((A1-A2)/A1)>.00001) {
		A2=A1;
		C9=-(A+M9)*(A+B+M9)*X/(A+2*M9)/(A+2*M9+1);
		A0=A1+C9*A0;
		B0=B1+C9*B0;
		M9=M9+1;
		C9=M9*(B-M9)*X/(A+2*M9-1)/(A+2*M9);
		A1=A0+C9*A1;
		B1=B0+C9*B1;
		A0=A0/B1;
		B0=B0/B1;
		A1=A1/B1;
		B1=1;
	}
	return A1/A
}

function computeBProb(x,n,P) {
    var X=eval(x)
    var N=eval(n)
    var P=eval(P)
    var bincdf, Betacdf;
		if (N<=0) {
			console.log("sample size must be positive")
		} else if ((P<0)||(P>1)) {
			console.log("probability must be between 0 and 1")
		} else if (X<0) {
			bincdf=0
		} else if (X>=N) {
			bincdf=1
		} else {
			X=Math.floor(X);
			var Z=P;
			var A=X+1;
			var B=N-X;
			var S=A+B;
			var BT=Math.exp(LogGamma(S)-LogGamma(B)-LogGamma(A)+A*Math.log(Z)+B*Math.log(1-Z));
			if (Z<(A+1)/(S+2)) {
				Betacdf=BT*Betinc(Z,A,B)
			} else {
				Betacdf=1-BT*Betinc(1-Z,B,A)
			}
			bincdf=1-Betacdf;
		}
		bincdf=Math.round(bincdf*100000)/100000;
 
    return bincdf;
}


var prob =  binomialProb( 0, 5, .07 );
var prv = runtimeScene.getVariables().get("prevalence").getAsNumber();
var partners = runtimeScene.getVariables().get("partners").getAsNumber();
 
 
 var exprisk = 1-binomialProb( 0, partners, prv )
runtimeScene.getVariables().get("risk").setNumber(Math.round(exprisk*1000)/1000);
console.log(exprisk)
};
gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDpartnersObjects3Objects = Hashtable.newFrom({"partners": gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3});gdjs.evtsExt__HIV__runExposure.eventsList0 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDchipObjects3Objects = Hashtable.newFrom({"chip": gdjs.evtsExt__HIV__runExposure.GDchipObjects3});gdjs.evtsExt__HIV__runExposure.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__HIV__runExposure.conditionTrue_1 = gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0;
gdjs.evtsExt__HIV__runExposure.conditionTrue_1.val = (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("risk")) * 100 > gdjs.random(100));
}
}if (gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0.val) {
gdjs.evtsExt__HIV__runExposure.GDchipObjects4.createFrom(gdjs.evtsExt__HIV__runExposure.GDchipObjects3);

{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDchipObjects4.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDchipObjects4[i].returnVariable(gdjs.evtsExt__HIV__runExposure.GDchipObjects4[i].getVariables().get("hit")).setNumber(1);
}
}}

}


};gdjs.evtsExt__HIV__runExposure.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


var objects = [];
gdjs.evtsExt__HIV__runExposure.userFunc0x6d3670(runtimeScene, objects, typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined);

}


{


{
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects2.createFrom(eventsFunctionContext.getObjects("partners"));
{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDpartnersObjects2.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDpartnersObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("cnt").setNumber(0);
}}

}


{


gdjs.evtsExt__HIV__runExposure.repeatCount3 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("partners"));
for(gdjs.evtsExt__HIV__runExposure.repeatIndex3 = 0;gdjs.evtsExt__HIV__runExposure.repeatIndex3 < gdjs.evtsExt__HIV__runExposure.repeatCount3;++gdjs.evtsExt__HIV__runExposure.repeatIndex3) {
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDpartnersObjects3Objects, 10 + gdjs.evtTools.common.mod(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cnt")), 10) * 20, 76, "");
}{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3[i].setWidth(20);
}
}{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3[i].setHeight(20);
}
}{runtimeScene.getVariables().get("cnt").add(1);
}}
}

}


{


gdjs.evtsExt__HIV__runExposure.repeatCount3 = 100;
for(gdjs.evtsExt__HIV__runExposure.repeatIndex3 = 0;gdjs.evtsExt__HIV__runExposure.repeatIndex3 < gdjs.evtsExt__HIV__runExposure.repeatCount3;++gdjs.evtsExt__HIV__runExposure.repeatIndex3) {
gdjs.evtsExt__HIV__runExposure.GDchipObjects3.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDchipObjects3Objects, 200 + gdjs.evtTools.common.mod(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cnt")), 10) * 45, 100 + gdjs.evtTools.common.mod(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("cnt")) / 10), 10) * 45, "");
}{runtimeScene.getVariables().get("cnt").add(1);
}{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDchipObjects3.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDchipObjects3[i].setWidth(25);
}
}{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDchipObjects3.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDchipObjects3[i].setHeight(25);
}
}
{ //Subevents: 
gdjs.evtsExt__HIV__runExposure.eventsList1(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}

}


{


{
gdjs.evtsExt__HIV__runExposure.GDchipObjects1.createFrom(eventsFunctionContext.getObjects("chip"));
{runtimeScene.getVariables().get("rollState").setNumber(1);
}{for(var i = 0, len = gdjs.evtsExt__HIV__runExposure.GDchipObjects1.length ;i < len;++i) {
    gdjs.evtsExt__HIV__runExposure.GDchipObjects1[i].setAnimation(2);
}
}}

}


};gdjs.evtsExt__HIV__runExposure.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.evtsExt__HIV__runExposure.GDrunObjects1.createFrom(eventsFunctionContext.getObjects("run"));

gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0.val = false;
gdjs.evtsExt__HIV__runExposure.condition1IsTrue_0.val = false;
gdjs.evtsExt__HIV__runExposure.condition2IsTrue_0.val = false;
{
gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.evtsExt__HIV__runExposure.condition0IsTrue_0.val ) {
{
gdjs.evtsExt__HIV__runExposure.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__HIV__runExposure.mapOfGDgdjs_46evtsExt_95_95HIV_95_95runExposure_46GDrunObjects1Objects, runtimeScene, true, false);
}if ( gdjs.evtsExt__HIV__runExposure.condition1IsTrue_0.val ) {
{
{gdjs.evtsExt__HIV__runExposure.conditionTrue_1 = gdjs.evtsExt__HIV__runExposure.condition2IsTrue_0;
gdjs.evtsExt__HIV__runExposure.conditionTrue_1.val = eventsFunctionContext.getOnceTriggers().triggerOnce(7412844);
}
}}
}
if (gdjs.evtsExt__HIV__runExposure.condition2IsTrue_0.val) {
{runtimeScene.getVariables().get("prevalence").setNumber((gdjs.random(10) + 1) / 100);
}{runtimeScene.getVariables().get("partners").setNumber(gdjs.random(10) + 1);
}
{ //Subevents
gdjs.evtsExt__HIV__runExposure.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__HIV__runExposure.func = function(runtimeScene, chip, partners, run, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"chip": chip
, "partners": partners
, "run": run
},
  _objectArraysMap: {
"chip": gdjs.objectsListsToArray(chip)
, "partners": gdjs.objectsListsToArray(partners)
, "run": gdjs.objectsListsToArray(run)
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    var objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      return parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
    }
    return null;
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__HIV__runExposure.GDchipObjects1.length = 0;
gdjs.evtsExt__HIV__runExposure.GDchipObjects2.length = 0;
gdjs.evtsExt__HIV__runExposure.GDchipObjects3.length = 0;
gdjs.evtsExt__HIV__runExposure.GDchipObjects4.length = 0;
gdjs.evtsExt__HIV__runExposure.GDchipObjects5.length = 0;
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects1.length = 0;
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects2.length = 0;
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects3.length = 0;
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects4.length = 0;
gdjs.evtsExt__HIV__runExposure.GDpartnersObjects5.length = 0;
gdjs.evtsExt__HIV__runExposure.GDrunObjects1.length = 0;
gdjs.evtsExt__HIV__runExposure.GDrunObjects2.length = 0;
gdjs.evtsExt__HIV__runExposure.GDrunObjects3.length = 0;
gdjs.evtsExt__HIV__runExposure.GDrunObjects4.length = 0;
gdjs.evtsExt__HIV__runExposure.GDrunObjects5.length = 0;

gdjs.evtsExt__HIV__runExposure.eventsList3(runtimeScene, eventsFunctionContext);
return;
}

