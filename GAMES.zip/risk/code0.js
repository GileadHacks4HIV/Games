gdjs.ExposureCode = {};
gdjs.ExposureCode.GDrunObjects1_1final = [];

gdjs.ExposureCode.repeatCount3 = 0;

gdjs.ExposureCode.repeatIndex3 = 0;

gdjs.ExposureCode.GDtxtRiskObjects1= [];
gdjs.ExposureCode.GDtxtRiskObjects2= [];
gdjs.ExposureCode.GDtxtRiskObjects3= [];
gdjs.ExposureCode.GDtxtRiskObjects4= [];
gdjs.ExposureCode.GDtxtRiskObjects5= [];
gdjs.ExposureCode.GDrunObjects1= [];
gdjs.ExposureCode.GDrunObjects2= [];
gdjs.ExposureCode.GDrunObjects3= [];
gdjs.ExposureCode.GDrunObjects4= [];
gdjs.ExposureCode.GDrunObjects5= [];
gdjs.ExposureCode.GDpartnersObjects1= [];
gdjs.ExposureCode.GDpartnersObjects2= [];
gdjs.ExposureCode.GDpartnersObjects3= [];
gdjs.ExposureCode.GDpartnersObjects4= [];
gdjs.ExposureCode.GDpartnersObjects5= [];
gdjs.ExposureCode.GDtxtPartnersObjects1= [];
gdjs.ExposureCode.GDtxtPartnersObjects2= [];
gdjs.ExposureCode.GDtxtPartnersObjects3= [];
gdjs.ExposureCode.GDtxtPartnersObjects4= [];
gdjs.ExposureCode.GDtxtPartnersObjects5= [];
gdjs.ExposureCode.GDtxtPrevObjects1= [];
gdjs.ExposureCode.GDtxtPrevObjects2= [];
gdjs.ExposureCode.GDtxtPrevObjects3= [];
gdjs.ExposureCode.GDtxtPrevObjects4= [];
gdjs.ExposureCode.GDtxtPrevObjects5= [];
gdjs.ExposureCode.GDNewObjectObjects1= [];
gdjs.ExposureCode.GDNewObjectObjects2= [];
gdjs.ExposureCode.GDNewObjectObjects3= [];
gdjs.ExposureCode.GDNewObjectObjects4= [];
gdjs.ExposureCode.GDNewObjectObjects5= [];
gdjs.ExposureCode.GDchipObjects1= [];
gdjs.ExposureCode.GDchipObjects2= [];
gdjs.ExposureCode.GDchipObjects3= [];
gdjs.ExposureCode.GDchipObjects4= [];
gdjs.ExposureCode.GDchipObjects5= [];
gdjs.ExposureCode.GDbgObjects1= [];
gdjs.ExposureCode.GDbgObjects2= [];
gdjs.ExposureCode.GDbgObjects3= [];
gdjs.ExposureCode.GDbgObjects4= [];
gdjs.ExposureCode.GDbgObjects5= [];
gdjs.ExposureCode.GDrunbtnObjects1= [];
gdjs.ExposureCode.GDrunbtnObjects2= [];
gdjs.ExposureCode.GDrunbtnObjects3= [];
gdjs.ExposureCode.GDrunbtnObjects4= [];
gdjs.ExposureCode.GDrunbtnObjects5= [];
gdjs.ExposureCode.GDcursorObjects1= [];
gdjs.ExposureCode.GDcursorObjects2= [];
gdjs.ExposureCode.GDcursorObjects3= [];
gdjs.ExposureCode.GDcursorObjects4= [];
gdjs.ExposureCode.GDcursorObjects5= [];

gdjs.ExposureCode.conditionTrue_0 = {val:false};
gdjs.ExposureCode.condition0IsTrue_0 = {val:false};
gdjs.ExposureCode.condition1IsTrue_0 = {val:false};
gdjs.ExposureCode.condition2IsTrue_0 = {val:false};
gdjs.ExposureCode.condition3IsTrue_0 = {val:false};
gdjs.ExposureCode.conditionTrue_1 = {val:false};
gdjs.ExposureCode.condition0IsTrue_1 = {val:false};
gdjs.ExposureCode.condition1IsTrue_1 = {val:false};
gdjs.ExposureCode.condition2IsTrue_1 = {val:false};
gdjs.ExposureCode.condition3IsTrue_1 = {val:false};
gdjs.ExposureCode.conditionTrue_2 = {val:false};
gdjs.ExposureCode.condition0IsTrue_2 = {val:false};
gdjs.ExposureCode.condition1IsTrue_2 = {val:false};
gdjs.ExposureCode.condition2IsTrue_2 = {val:false};
gdjs.ExposureCode.condition3IsTrue_2 = {val:false};


gdjs.ExposureCode.eventsList0 = function(runtimeScene) {

};gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDrunObjects2Objects = Hashtable.newFrom({"run": gdjs.ExposureCode.GDrunObjects2});gdjs.ExposureCode.userFunc0x6c4010 = function(runtimeScene, objects) {
"use strict";
/**
Calcuate Risk

e.g.
The probability that a person has HIV infection is hiv_risk (.07) 
If one has sexual contact with 5 partners 
what is the probability that none has HIV infection?

Solution: To solve this problem, we compute 3 individual probabilities, using the binomial formula. The sum of all these probabilities is the answer we seek. Thus,
b(x = 0; 5, 0.3) = b(x = 0; 5, 0.07)  

x ( hits ) = 0
n ( times/picks ) = 5
P ( probablity/risk ) = .07


Given x, n, and P, we can compute the binomial probability based on the binomial formula:
Binomial Formula. 
Suppose a binomial experiment consists of n trials and results in x successes. If the probability of success on an individual trial is P, then the binomial probability is:
b(x; n, P) = nCx * Px * (1 - P)n - x
b(x; n, P) = { n! / [ x! (n - x)! ] } * Px * (1 - P)n - x
**/
function binomialProb( x, n, P ){

/**
use funcions from 
view-source:https://www.math.ucla.edu/~tom/distributions/binomial.html?
**/
	return computeBProb( x, n, P )
 

}



function LogGamma(Z) {
	 
		var S=1+76.18009173/Z-86.50532033/(Z+1)+24.01409822/(Z+2)-1.231739516/(Z+3)+.00120858003/(Z+4)-.00000536382/(Z+5);
		var LG= (Z-.5)*Math.log(Z+4.5)-(Z+4.5)+Math.log(S*2.50662827465);
	 
	return LG
}

function Betinc(X,A,B) {
	var A0=0;
	var B0=1;
	var A1=1;
	var B1=1;
	var M9=0;
	var A2=0;
	var C9;
	while (Math.abs((A1-A2)/A1)>.00001) {
		A2=A1;
		C9=-(A+M9)*(A+B+M9)*X/(A+2*M9)/(A+2*M9+1);
		A0=A1+C9*A0;
		B0=B1+C9*B0;
		M9=M9+1;
		C9=M9*(B-M9)*X/(A+2*M9-1)/(A+2*M9);
		A1=A0+C9*A1;
		B1=B0+C9*B1;
		A0=A0/B1;
		B0=B0/B1;
		A1=A1/B1;
		B1=1;
	}
	return A1/A
}

function computeBProb(x,n,P) {
    var X=eval(x)
    var N=eval(n)
    var P=eval(P)
    var bincdf, Betacdf;
		if (N<=0) {
			console.log("sample size must be positive")
		} else if ((P<0)||(P>1)) {
			console.log("probability must be between 0 and 1")
		} else if (X<0) {
			bincdf=0
		} else if (X>=N) {
			bincdf=1
		} else {
			X=Math.floor(X);
			var Z=P;
			var A=X+1;
			var B=N-X;
			var S=A+B;
			var BT=Math.exp(LogGamma(S)-LogGamma(B)-LogGamma(A)+A*Math.log(Z)+B*Math.log(1-Z));
			if (Z<(A+1)/(S+2)) {
				Betacdf=BT*Betinc(Z,A,B)
			} else {
				Betacdf=1-BT*Betinc(1-Z,B,A)
			}
			bincdf=1-Betacdf;
		}
		bincdf=Math.round(bincdf*100000)/100000;
 
    return bincdf;
}


var prob =  binomialProb( 0, 5, .07 );
var prv = runtimeScene.getVariables().get("prevalence").getAsNumber();
var partners = runtimeScene.getVariables().get("partners").getAsNumber();
 
 
 var exprisk = 1-binomialProb( 0, partners, prv )
runtimeScene.getVariables().get("risk").setNumber(Math.round(exprisk*1000)/1000);
console.log(exprisk)
};
gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDpartnersObjects3Objects = Hashtable.newFrom({"partners": gdjs.ExposureCode.GDpartnersObjects3});gdjs.ExposureCode.eventsList1 = function(runtimeScene) {

};gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects3Objects = Hashtable.newFrom({"chip": gdjs.ExposureCode.GDchipObjects3});gdjs.ExposureCode.eventsList2 = function(runtimeScene) {

{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
{gdjs.ExposureCode.conditionTrue_1 = gdjs.ExposureCode.condition0IsTrue_0;
gdjs.ExposureCode.conditionTrue_1.val = (gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) * 100 > gdjs.random(100));
}
}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
gdjs.ExposureCode.GDchipObjects4.createFrom(gdjs.ExposureCode.GDchipObjects3);

{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects4.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects4[i].returnVariable(gdjs.ExposureCode.GDchipObjects4[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


};gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects1Objects = Hashtable.newFrom({"chip": gdjs.ExposureCode.GDchipObjects1});gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDcursorObjects1Objects = Hashtable.newFrom({"cursor": gdjs.ExposureCode.GDcursorObjects1});gdjs.ExposureCode.eventsList3 = function(runtimeScene) {

{


var objects = [];
gdjs.ExposureCode.userFunc0x6c4010(runtimeScene, objects);

}


{


{
gdjs.ExposureCode.GDchipObjects2.createFrom(runtimeScene.getObjects("chip"));
gdjs.ExposureCode.GDcursorObjects2.createFrom(runtimeScene.getObjects("cursor"));
gdjs.ExposureCode.GDpartnersObjects2.createFrom(runtimeScene.getObjects("partners"));
{for(var i = 0, len = gdjs.ExposureCode.GDpartnersObjects2.length ;i < len;++i) {
    gdjs.ExposureCode.GDpartnersObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(3).setNumber(0);
}{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects2.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ExposureCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.ExposureCode.GDcursorObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.ExposureCode.repeatCount3 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1));
for(gdjs.ExposureCode.repeatIndex3 = 0;gdjs.ExposureCode.repeatIndex3 < gdjs.ExposureCode.repeatCount3;++gdjs.ExposureCode.repeatIndex3) {
gdjs.ExposureCode.GDpartnersObjects3.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDpartnersObjects3Objects, 10 + gdjs.evtTools.common.mod(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 10) * 20, 76, "");
}{for(var i = 0, len = gdjs.ExposureCode.GDpartnersObjects3.length ;i < len;++i) {
    gdjs.ExposureCode.GDpartnersObjects3[i].setWidth(20);
}
}{for(var i = 0, len = gdjs.ExposureCode.GDpartnersObjects3.length ;i < len;++i) {
    gdjs.ExposureCode.GDpartnersObjects3[i].setHeight(20);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}}
}

}


{


gdjs.ExposureCode.repeatCount3 = 100;
for(gdjs.ExposureCode.repeatIndex3 = 0;gdjs.ExposureCode.repeatIndex3 < gdjs.ExposureCode.repeatCount3;++gdjs.ExposureCode.repeatIndex3) {
gdjs.ExposureCode.GDchipObjects3.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects3Objects, 200 + gdjs.evtTools.common.mod(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 10) * 45, 150 + gdjs.evtTools.common.mod(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) / 10), 10) * 45, "");
}{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects3.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects3[i].setAnimation(2);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects3.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects3[i].setWidth(35);
}
}{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects3.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects3[i].setHeight(35);
}
}
{ //Subevents: 
gdjs.ExposureCode.eventsList2(runtimeScene);} //Subevents end.
}
}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).setNumber(1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "game");
}}

}


{

gdjs.ExposureCode.GDchipObjects1.createFrom(runtimeScene.getObjects("chip"));

gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects1Objects);
}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
/* Reuse gdjs.ExposureCode.GDchipObjects1 */
gdjs.ExposureCode.GDcursorObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDcursorObjects1Objects, (( gdjs.ExposureCode.GDchipObjects1.length === 0 ) ? 0 :gdjs.ExposureCode.GDchipObjects1[0].getPointX("")), (( gdjs.ExposureCode.GDchipObjects1.length === 0 ) ? 0 :gdjs.ExposureCode.GDchipObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ExposureCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDcursorObjects1[i].setWidth(50);
}
}{for(var i = 0, len = gdjs.ExposureCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDcursorObjects1[i].setHeight(50);
}
}}

}


};gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects1Objects = Hashtable.newFrom({"chip": gdjs.ExposureCode.GDchipObjects1});gdjs.ExposureCode.eventsList4 = function(runtimeScene) {

{

gdjs.ExposureCode.GDchipObjects2.createFrom(gdjs.ExposureCode.GDchipObjects1);


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ExposureCode.GDchipObjects2.length;i<l;++i) {
    if ( gdjs.ExposureCode.GDchipObjects2[i].getVariableNumber(gdjs.ExposureCode.GDchipObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.ExposureCode.condition0IsTrue_0.val = true;
        gdjs.ExposureCode.GDchipObjects2[k] = gdjs.ExposureCode.GDchipObjects2[i];
        ++k;
    }
}
gdjs.ExposureCode.GDchipObjects2.length = k;}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
}

}


{

gdjs.ExposureCode.GDchipObjects2.createFrom(gdjs.ExposureCode.GDchipObjects1);


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ExposureCode.GDchipObjects2.length;i<l;++i) {
    if ( gdjs.ExposureCode.GDchipObjects2[i].getVariableNumber(gdjs.ExposureCode.GDchipObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.ExposureCode.condition0IsTrue_0.val = true;
        gdjs.ExposureCode.GDchipObjects2[k] = gdjs.ExposureCode.GDchipObjects2[i];
        ++k;
    }
}
gdjs.ExposureCode.GDchipObjects2.length = k;}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).setNumber(2);
}}

}


};gdjs.ExposureCode.eventsList5 = function(runtimeScene) {

{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(0.05);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(1);
}{runtimeScene.getVariables().getFromIndex(2).setNumber(0.02);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "game");
}{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


{


gdjs.ExposureCode.eventsList0(runtimeScene);
}


{

gdjs.ExposureCode.GDrunObjects1.length = 0;


gdjs.ExposureCode.condition0IsTrue_0.val = false;
gdjs.ExposureCode.condition1IsTrue_0.val = false;
{
{gdjs.ExposureCode.conditionTrue_1 = gdjs.ExposureCode.condition0IsTrue_0;
gdjs.ExposureCode.GDrunObjects1_1final.length = 0;gdjs.ExposureCode.condition0IsTrue_1.val = false;
gdjs.ExposureCode.condition1IsTrue_1.val = false;
gdjs.ExposureCode.condition2IsTrue_1.val = false;
{
gdjs.ExposureCode.condition0IsTrue_1.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if( gdjs.ExposureCode.condition0IsTrue_1.val ) {
    gdjs.ExposureCode.conditionTrue_1.val = true;
}
}
{
gdjs.ExposureCode.GDrunObjects2.createFrom(runtimeScene.getObjects("run"));
{gdjs.ExposureCode.conditionTrue_2 = gdjs.ExposureCode.condition1IsTrue_1;
gdjs.ExposureCode.condition0IsTrue_2.val = false;
gdjs.ExposureCode.condition1IsTrue_2.val = false;
gdjs.ExposureCode.condition2IsTrue_2.val = false;
{
gdjs.ExposureCode.condition0IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.ExposureCode.condition0IsTrue_2.val ) {
{
gdjs.ExposureCode.condition1IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDrunObjects2Objects, runtimeScene, true, false);
}if ( gdjs.ExposureCode.condition1IsTrue_2.val ) {
{
gdjs.ExposureCode.condition2IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 0;
}}
}
gdjs.ExposureCode.conditionTrue_2.val = true && gdjs.ExposureCode.condition0IsTrue_2.val && gdjs.ExposureCode.condition1IsTrue_2.val && gdjs.ExposureCode.condition2IsTrue_2.val;
}
if( gdjs.ExposureCode.condition1IsTrue_1.val ) {
    gdjs.ExposureCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.ExposureCode.GDrunObjects2.length;j<jLen;++j) {
        if ( gdjs.ExposureCode.GDrunObjects1_1final.indexOf(gdjs.ExposureCode.GDrunObjects2[j]) === -1 )
            gdjs.ExposureCode.GDrunObjects1_1final.push(gdjs.ExposureCode.GDrunObjects2[j]);
    }
}
}
{
{gdjs.ExposureCode.conditionTrue_2 = gdjs.ExposureCode.condition2IsTrue_1;
gdjs.ExposureCode.condition0IsTrue_2.val = false;
gdjs.ExposureCode.condition1IsTrue_2.val = false;
{
gdjs.ExposureCode.condition0IsTrue_2.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "game");
}if ( gdjs.ExposureCode.condition0IsTrue_2.val ) {
{
gdjs.ExposureCode.condition1IsTrue_2.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 0;
}}
gdjs.ExposureCode.conditionTrue_2.val = true && gdjs.ExposureCode.condition0IsTrue_2.val && gdjs.ExposureCode.condition1IsTrue_2.val;
}
if( gdjs.ExposureCode.condition2IsTrue_1.val ) {
    gdjs.ExposureCode.conditionTrue_1.val = true;
}
}
{
gdjs.ExposureCode.GDrunObjects1.createFrom(gdjs.ExposureCode.GDrunObjects1_1final);
}
}
}if ( gdjs.ExposureCode.condition0IsTrue_0.val ) {
{
{gdjs.ExposureCode.conditionTrue_1 = gdjs.ExposureCode.condition1IsTrue_0;
gdjs.ExposureCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7562004);
}
}}
if (gdjs.ExposureCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setNumber((gdjs.random(10) + 1) / 100);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(gdjs.random(10) + 1);
}
{ //Subevents
gdjs.ExposureCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
gdjs.ExposureCode.GDtxtPartnersObjects1.createFrom(runtimeScene.getObjects("txtPartners"));
gdjs.ExposureCode.GDtxtPrevObjects1.createFrom(runtimeScene.getObjects("txtPrev"));
gdjs.ExposureCode.GDtxtRiskObjects1.createFrom(runtimeScene.getObjects("txtRisk"));
{for(var i = 0, len = gdjs.ExposureCode.GDtxtRiskObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDtxtRiskObjects1[i].setString(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) * 100)) + "%");
}
}{for(var i = 0, len = gdjs.ExposureCode.GDtxtPartnersObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDtxtPartnersObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs.ExposureCode.GDtxtPrevObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDtxtPrevObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) * 100) + "%");
}
}}

}


{

gdjs.ExposureCode.GDchipObjects1.createFrom(runtimeScene.getObjects("chip"));

gdjs.ExposureCode.condition0IsTrue_0.val = false;
gdjs.ExposureCode.condition1IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.ExposureCode.condition0IsTrue_0.val ) {
{
gdjs.ExposureCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ExposureCode.mapOfGDgdjs_46ExposureCode_46GDchipObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.ExposureCode.condition1IsTrue_0.val) {
/* Reuse gdjs.ExposureCode.GDchipObjects1 */
{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects1[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.ExposureCode.GDchipObjects1[i].getVariables().getFromIndex(0))));
}
}
{ //Subevents
gdjs.ExposureCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
gdjs.ExposureCode.condition1IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "game");
}if ( gdjs.ExposureCode.condition0IsTrue_0.val ) {
{
gdjs.ExposureCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 1;
}}
if (gdjs.ExposureCode.condition1IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).setNumber(2);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "game");
}}

}


{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 2;
}if (gdjs.ExposureCode.condition0IsTrue_0.val) {
gdjs.ExposureCode.GDchipObjects1.createFrom(runtimeScene.getObjects("chip"));
{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects1[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.ExposureCode.GDchipObjects1[i].getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs.ExposureCode.GDchipObjects1.length ;i < len;++i) {
    gdjs.ExposureCode.GDchipObjects1[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getVariables().getFromIndex(4).setNumber(3);
}}

}


{


gdjs.ExposureCode.condition0IsTrue_0.val = false;
gdjs.ExposureCode.condition1IsTrue_0.val = false;
{
gdjs.ExposureCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "game");
}if ( gdjs.ExposureCode.condition0IsTrue_0.val ) {
{
gdjs.ExposureCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 3;
}}
if (gdjs.ExposureCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "game");
}{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}}

}


};

gdjs.ExposureCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ExposureCode.GDtxtRiskObjects1.length = 0;
gdjs.ExposureCode.GDtxtRiskObjects2.length = 0;
gdjs.ExposureCode.GDtxtRiskObjects3.length = 0;
gdjs.ExposureCode.GDtxtRiskObjects4.length = 0;
gdjs.ExposureCode.GDtxtRiskObjects5.length = 0;
gdjs.ExposureCode.GDrunObjects1.length = 0;
gdjs.ExposureCode.GDrunObjects2.length = 0;
gdjs.ExposureCode.GDrunObjects3.length = 0;
gdjs.ExposureCode.GDrunObjects4.length = 0;
gdjs.ExposureCode.GDrunObjects5.length = 0;
gdjs.ExposureCode.GDpartnersObjects1.length = 0;
gdjs.ExposureCode.GDpartnersObjects2.length = 0;
gdjs.ExposureCode.GDpartnersObjects3.length = 0;
gdjs.ExposureCode.GDpartnersObjects4.length = 0;
gdjs.ExposureCode.GDpartnersObjects5.length = 0;
gdjs.ExposureCode.GDtxtPartnersObjects1.length = 0;
gdjs.ExposureCode.GDtxtPartnersObjects2.length = 0;
gdjs.ExposureCode.GDtxtPartnersObjects3.length = 0;
gdjs.ExposureCode.GDtxtPartnersObjects4.length = 0;
gdjs.ExposureCode.GDtxtPartnersObjects5.length = 0;
gdjs.ExposureCode.GDtxtPrevObjects1.length = 0;
gdjs.ExposureCode.GDtxtPrevObjects2.length = 0;
gdjs.ExposureCode.GDtxtPrevObjects3.length = 0;
gdjs.ExposureCode.GDtxtPrevObjects4.length = 0;
gdjs.ExposureCode.GDtxtPrevObjects5.length = 0;
gdjs.ExposureCode.GDNewObjectObjects1.length = 0;
gdjs.ExposureCode.GDNewObjectObjects2.length = 0;
gdjs.ExposureCode.GDNewObjectObjects3.length = 0;
gdjs.ExposureCode.GDNewObjectObjects4.length = 0;
gdjs.ExposureCode.GDNewObjectObjects5.length = 0;
gdjs.ExposureCode.GDchipObjects1.length = 0;
gdjs.ExposureCode.GDchipObjects2.length = 0;
gdjs.ExposureCode.GDchipObjects3.length = 0;
gdjs.ExposureCode.GDchipObjects4.length = 0;
gdjs.ExposureCode.GDchipObjects5.length = 0;
gdjs.ExposureCode.GDbgObjects1.length = 0;
gdjs.ExposureCode.GDbgObjects2.length = 0;
gdjs.ExposureCode.GDbgObjects3.length = 0;
gdjs.ExposureCode.GDbgObjects4.length = 0;
gdjs.ExposureCode.GDbgObjects5.length = 0;
gdjs.ExposureCode.GDrunbtnObjects1.length = 0;
gdjs.ExposureCode.GDrunbtnObjects2.length = 0;
gdjs.ExposureCode.GDrunbtnObjects3.length = 0;
gdjs.ExposureCode.GDrunbtnObjects4.length = 0;
gdjs.ExposureCode.GDrunbtnObjects5.length = 0;
gdjs.ExposureCode.GDcursorObjects1.length = 0;
gdjs.ExposureCode.GDcursorObjects2.length = 0;
gdjs.ExposureCode.GDcursorObjects3.length = 0;
gdjs.ExposureCode.GDcursorObjects4.length = 0;
gdjs.ExposureCode.GDcursorObjects5.length = 0;

gdjs.ExposureCode.eventsList5(runtimeScene);
return;

}

gdjs['ExposureCode'] = gdjs.ExposureCode;
